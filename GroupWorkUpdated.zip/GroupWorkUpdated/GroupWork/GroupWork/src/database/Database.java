package database;

import team1.EmployeeManagement;
import team1.Employee;
import team1.Menu;


import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import CustomException.IdNotFound;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;



public class Database implements EmployeeManagement{
		   private static Connection connection;
		   private Properties properties;
		   public Database() {
		       initializeDatabaseConnection();
		   }
		   private void initializeDatabaseConnection() {
			   Properties properties = new Properties();
		       try {		           
		           //properties.load(getClass().getClassLoader().getResourceAsStream("db.properties"));
		    	   FileInputStream input = new FileInputStream("C://Users/MSIS/Desktop/Lab_Exam_Java/GroupWork/db.properties");
		           properties.load(input);
		           String connectionUrl = "jdbc:sqlserver://172.16.51.64;" + "databaseName=231047010;encrypt=true;trustServerCertificate=true";
		           String username = properties.getProperty("username");
		           String password = properties.getProperty("password");
		           connection = DriverManager.getConnection(connectionUrl, username, password);
		           System.out.println("Successfully connected to the database");
		       } catch (Exception e) {
		           e.printStackTrace();
		       }
		   }
	
	
	@Override
	public void addEmployee(Employee employee) {
		String sql = "INSERT INTO Employeemanage(employee_id, employee_name, employee_Sal, employee_des) VALUES (?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, employee.getId());
            statement.setString(2, employee.getName());
            statement.setDouble(3, employee.getSalary());
            statement.setString(4, calculateDesignation(employee.getSalary()));
            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Employee added successfully to the database");
            } else {
                System.out.println("Failed to add employee to the database");
            }
        }catch (SQLException e) {
            e.printStackTrace();
        }
    } 
		
	
	@Override
	public void deleteEmployee(int employeeId) {
		   try {
	           String sql = "DELETE FROM Employeemanage WHERE employee_id = ?";
	           try (PreparedStatement statement = connection.prepareStatement(sql)) {
	               statement.setInt(1, employeeId);
	               int rowsAffected = statement.executeUpdate();
	               if (rowsAffected > 0) {
	                   System.out.println("Employee deleted successfully from the database");
	               } else {
	                   System.out.println("Failed to delete employee from the database");
	               }
	           }
	       } catch (SQLException e) {
	           e.printStackTrace();
	       }
	   }
	
	@Override
	public void updateEmployee(int employeeId, Employee newEmployee) throws IdNotFound {
		try {
	           String sql = "UPDATE Employeemanage SET employee_name = ?, employee_Sal = ?, employee_des = ? WHERE employee_id = ?";
	           try (PreparedStatement statement = connection.prepareStatement(sql)) {
	               statement.setString(1, newEmployee.getName());
	               statement.setDouble(2, newEmployee.getSalary());
	               statement.setString(3, calculateDesignation(newEmployee.getSalary()));
	               statement.setInt(4, employeeId);
	               int rowsAffected = statement.executeUpdate();
	               if (rowsAffected > 0) {
	                   System.out.println("Employee updated successfully in the database");
	               } else {
	                   throw new IdNotFound("Employee ID not found.");
	               }
	           }
	       } catch (SQLException e) {
	           e.printStackTrace();
	       }
		
	}
	@Override
	public List<Employee> listEmployees() {
		List<Employee> employees = new ArrayList<>();
	       try {
	           String sql = "SELECT * FROM Employeemanage";
	           try (PreparedStatement statement = connection.prepareStatement(sql)) {
	               ResultSet rs = statement.executeQuery();
	               while (rs.next()) {
	                   int id = rs.getInt("employee_id");
	                   String name = rs.getString("employee_name");
	                   double salary = rs.getDouble("employee_Sal");
	                   String designation = rs.getString("employee_des");
	                   Employee employee = new Employee(id, name, salary);
	                   employees.add(employee);
	               }
	           }
	       } catch (SQLException e) {
	           e.printStackTrace();
	       }
	       return employees;
	}
	   private String calculateDesignation(double salary) {
	       // Add your logic here to determine the designation based on the salary
	       // This is a placeholder, replace it with your actual logic
	       if (salary > 50000) {
	           return "Manager";
	       } else {
	           return "Employee";
	       }
	   }
	 /*  public static void main(String[] args) {
		   Database employeeDb = new Database();
	       // Example usage:
	       Employee newEmployee = new Employee(103, "XYZ", 62000.0);
	       employeeDb.addEmployee(newEmployee);
	       List<Employee> employeeList = employeeDb.listEmployees();
	       for (Employee emp : employeeList) {
	           System.out.println(emp);
	       }
	   }*/
}

