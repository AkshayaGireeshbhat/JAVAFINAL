module GroupWork {
	requires org.apache.logging.log4j;
	requires java.sql;
	

}